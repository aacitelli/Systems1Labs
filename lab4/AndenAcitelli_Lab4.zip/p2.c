/* Prototype by Anden Acitelli.2 */ 
/* The purpose of this prototype is to test that I can read in argc, argv correctly. */ 
#include <stdio.h> 
int main(int argc, char *argv[]) {
    fprintf(stdout, "argc: (should be 1): %d\n", argc); 
}