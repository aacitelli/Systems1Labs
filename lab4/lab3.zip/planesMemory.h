#include "structs.h"

#ifndef PLANESMEMORY_H
#define PLANESMEMORY_H

Plane *allocatePlane(); 
void freePlane(Plane *plane); 

#endif 